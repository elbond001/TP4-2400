#include "ElementTypes.h"

// Rien de particulier ici, on a déjà tout inlined dans .h
