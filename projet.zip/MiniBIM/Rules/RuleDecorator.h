#ifndef RULEDECORATOR_H
#define RULEDECORATOR_H

#include "../Element.h"
#include "Rule.h"

class RuleDecorator : public IElement {
private:
    IElement* baseElement;
    Rule* rule;  // <- Pointeur vers une règle
public:
    RuleDecorator(IElement* element, Rule* rule);
    virtual ~RuleDecorator();

    std::string getName() const override;
    std::string getElementType() const override;

    Rule* getRule() const;
};

#endif